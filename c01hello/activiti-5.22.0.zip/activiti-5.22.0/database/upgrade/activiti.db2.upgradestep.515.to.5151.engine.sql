
update ACT_GE_PROPERTY set VALUE_ = '5.15.1' where NAME_ = 'schema.version';
