alter table ACT_HI_PROCINST
	add NAME_ varchar(255);
	
